export type RawRow = {
  id: string;
  date: string;
  product: string;
  qty: string;
  price: string;
  status: string;
  note?: string;
  bad?: Array<"id" | "date" | "product" | "price" | "status" | "note">;
};

export const RAW_ROWS: RawRow[] = [
  { id: "1001", date: "03/01/2026", product: "Bamboo Cutlery Set", qty: "2", price: "12.99", status: "paid" },
  { id: "1002", date: "3/2/2026", product: "bamboo cutlery set", qty: "1", price: "13.99", status: "Paid", note: "price diff?", bad: ["date", "product", "price", "note"] },
  { id: "1003", date: "—", product: "Reusable Straws", qty: "3", price: "6.5", status: "PAID", bad: ["date", "status"] },
  { id: "1004", date: "03/04/26", product: "Reusable  Straws", qty: "1", price: "6.5", status: "refunded", note: "refund not logged", bad: ["date", "product", "note"] },
  { id: "1005", date: "03/05/2026", product: "Bamboo cutlery Set", qty: "2", price: "12.99", status: "paid", note: "dup of 1001?", bad: ["product", "note"] },
  { id: "—", date: "03/06/2026", product: "Tote Bag - Canvas", qty: "5", price: "9.99", status: "pending", note: "missing order id", bad: ["id", "note"] },
  { id: "1007", date: "03/07/2026", product: "Tote Bag Canvas", qty: "2", price: "9.99", status: "paid", bad: ["product"] },
];

export type CleanRow = {
  id: string;
  date: string;
  product: string;
  qty: string;
  price: string;
  total: string;
  status: "Paid" | "Refunded" | "Pending";
  flag?: string;
};

export const CLEAN_ROWS: CleanRow[] = [
  { id: "1001", date: "2026-03-01", product: "Bamboo Cutlery Set", qty: "2", price: "$12.99", total: "$25.98", status: "Paid" },
  { id: "1002", date: "2026-03-02", product: "Bamboo Cutlery Set", qty: "1", price: "$12.99", total: "$12.99", status: "Paid", flag: "Price corrected (was 13.99)" },
  { id: "1003", date: "2026-03-03", product: "Reusable Straws", qty: "3", price: "$6.50", total: "$19.50", status: "Paid" },
  { id: "1004", date: "2026-03-04", product: "Reusable Straws", qty: "1", price: "$6.50", total: "$6.50", status: "Refunded", flag: "Refund now logged" },
  { id: "1005", date: "2026-03-05", product: "Bamboo Cutlery Set", qty: "2", price: "$12.99", total: "$25.98", status: "Paid", flag: "Confirmed not a duplicate" },
  { id: "1006", date: "2026-03-06", product: "Tote Bag - Canvas", qty: "5", price: "$9.99", total: "$49.95", status: "Pending", flag: "Order ID assigned" },
  { id: "1007", date: "2026-03-07", product: "Tote Bag - Canvas", qty: "2", price: "$9.99", total: "$19.98", status: "Paid" },
];

export const TOTAL_REVENUE = "$160.88";
