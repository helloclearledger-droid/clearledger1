import { CountUp, Reveal } from "@/components/Reveal";
import { SheetMock } from "@/components/SheetMock";

const TRUST = [
  "Amazon", "Shopify", "Etsy", "eBay", "Stripe", "PayPal", "Xero", "QuickBooks",
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-28">
      {/* ambient background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 grid-lines opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,#000,transparent)]" />
        <div className="animate-drift absolute -top-40 left-1/2 h-[560px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,rgba(14,165,233,0.35),transparent_65%)] blur-3xl" />
        <div className="animate-drift absolute -right-32 top-24 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.28),transparent_65%)] blur-3xl [animation-delay:-8s]" />
        <div className="animate-drift absolute -left-24 top-60 h-[380px] w-[380px] rounded-full bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.25),transparent_65%)] blur-3xl [animation-delay:-14s]" />
        <div className="noise absolute inset-0 opacity-[0.035] mix-blend-overlay" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-[1.02fr_1fr] lg:gap-10">
        <div>
          <Reveal>
            <a
              href="#contact"
              className="glass group inline-flex items-center gap-2.5 rounded-full py-1.5 pl-1.5 pr-4 text-xs font-medium text-slate-200 transition-colors hover:text-white sm:text-[13px]"
            >
              <span className="rounded-full bg-gradient-to-r from-brand-400 to-mint-400 px-2.5 py-1 text-[11px] font-bold text-ink-950">
                NEW
              </span>
              Free 30-minute data audit for UK &amp; US sellers
              <span className="transition-transform duration-300 group-hover:translate-x-0.5">→</span>
            </a>
          </Reveal>

          <Reveal delay={90}>
            <h1 className="mt-7 font-display text-[2.6rem] font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl lg:text-[4.1rem]">
              Your sales data,
              <br />
              <span className="text-gradient animate-shimmer">clean and reconciled</span>
              <br />
              every single month.
            </h1>
          </Reveal>

          <Reveal delay={170}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
              Freelance operations support for small Amazon, Shopify and Etsy sellers in the UK and US.
              I turn messy exports into organised sheets, match every order against payments and refunds,
              and flag the mismatches that quietly cost you money.
            </p>
          </Reveal>

          <Reveal delay={240}>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
              <a
                href="#contact"
                className="group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-brand-400 via-brand-300 to-mint-400 px-7 py-4 text-[15px] font-bold text-ink-950 shadow-[0_18px_44px_-18px_rgba(56,189,248,0.9)] transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_22px_60px_-18px_rgba(52,211,153,0.9)]"
              >
                <span className="relative z-10">Get my free data audit</span>
                <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">→</span>
                <span className="absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.75),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
              </a>
              <a
                href="#proof"
                className="glass inline-flex items-center justify-center gap-2 rounded-full px-7 py-4 text-[15px] font-semibold text-white transition-all duration-300 hover:bg-white/10"
              >
                See before &amp; after
              </a>
            </div>
          </Reveal>

          <Reveal delay={310}>
            <dl className="mt-11 grid max-w-lg grid-cols-3 gap-5">
              {[
                { v: <CountUp to={48} suffix="h" />, l: "Typical turnaround" },
                { v: <CountUp to={1000} suffix="+" />, l: "Rows cleaned per task" },
                { v: <><CountUp to={100} suffix="%" /></>, l: "Money-back on first task" },
              ].map((s) => (
                <div key={s.l}>
                  <dt className="font-display text-2xl font-bold text-white sm:text-3xl">{s.v}</dt>
                  <dd className="mt-1 text-[12px] leading-snug text-slate-400">{s.l}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        {/* Visual */}
        <Reveal delay={260} className="relative">
          <div className="relative">
            <div
              aria-hidden="true"
              className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-[conic-gradient(from_180deg_at_50%_50%,rgba(56,189,248,0.25),rgba(52,211,153,0.2),rgba(99,102,241,0.25),rgba(56,189,248,0.25))] blur-2xl"
            />
            <div className="glass animate-floaty rounded-[1.75rem] p-3 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.9)]">
              <SheetMock mode="after" compact />
            </div>

            <div className="glass animate-floaty absolute -bottom-8 -left-4 w-52 rounded-2xl p-4 shadow-2xl [animation-delay:-3s] sm:-left-10 sm:w-60">
              <p className="text-[11px] uppercase tracking-wider text-slate-400">Mismatches caught</p>
              <p className="mt-1 font-display text-3xl font-bold text-mint-300">
                <CountUp to={4} />
              </p>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div className="h-full w-4/5 rounded-full bg-gradient-to-r from-brand-400 to-mint-400" />
              </div>
              <p className="mt-2 text-[11px] text-slate-400">refund, duplicate, price, missing ID</p>
            </div>

            <div className="glass animate-floaty absolute -top-6 right-0 hidden items-center gap-2.5 rounded-2xl px-4 py-3 shadow-2xl [animation-delay:-5s] sm:flex">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-mint-400/15 text-mint-300">✓</span>
              <div>
                <p className="text-[13px] font-semibold text-white">Books balanced</p>
                <p className="text-[11px] text-slate-400">March 2026 · 7/7 orders</p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* Logo marquee */}
      <Reveal delay={120} className="mt-24">
        <p className="text-center text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
          Built around the tools UK &amp; US sellers already run on
        </p>
        <div className="marquee-mask mt-7 flex overflow-hidden">
          <div className="animate-marquee flex shrink-0 items-center gap-12 pr-12">
            {[...TRUST, ...TRUST].map((name, i) => (
              <span
                key={i}
                className="font-display text-xl font-bold tracking-tight text-slate-500/70 transition-colors duration-300 hover:text-white sm:text-2xl"
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
