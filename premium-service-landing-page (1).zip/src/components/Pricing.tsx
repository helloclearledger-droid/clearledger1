import { useState } from "react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";
import { cn } from "@/utils/cn";

type Plan = {
  name: string;
  best: string;
  usd: number;
  gbp: number;
  unit: string;
  features: string[];
  popular?: boolean;
  cta: string;
};

const PLANS: Plan[] = [
  {
    name: "One-Time Cleanup",
    best: "A single messy dataset that needs sorting once",
    usd: 60,
    gbp: 48,
    unit: "flat",
    cta: "Start a cleanup",
    features: [
      "Clean + organise up to 1,000 rows",
      "Orders or inventory data",
      "Standardised dates, names & pricing",
      "Summary of everything fixed",
      "48-hour turnaround",
    ],
  },
  {
    name: "Reconciliation Task",
    best: "Matching sales vs payments vs refunds",
    usd: 90,
    gbp: 72,
    unit: "flat",
    cta: "Reconcile my month",
    features: [
      "Full reconciliation report",
      "Every mismatch flagged with a reason",
      "Refunds, payouts & fee checks",
      "Clean workbook delivered back",
      "48-hour turnaround",
    ],
  },
  {
    name: "Retainer · Starter",
    best: "Ongoing light support, month after month",
    usd: 150,
    gbp: 120,
    unit: "/mo",
    popular: true,
    cta: "Start the retainer",
    features: [
      "Up to 4 hrs/month cleanup + reconciliation",
      "Rolling monthly reporting pack",
      "Stock & pricing error monitoring",
      "Email support within 1 business day",
      "Cancel any month, no lock-in",
    ],
  },
  {
    name: "Retainer · Growth",
    best: "Sellers with regular, higher data volume",
    usd: 320,
    gbp: 255,
    unit: "/mo",
    cta: "Talk about Growth",
    features: [
      "Up to 10 hrs/month of support",
      "Priority turnaround on every task",
      "Multi-channel data merges",
      "Custom dashboard or summary sheet",
      "Monthly 30-min review call",
    ],
  },
];

export function Pricing() {
  const [currency, setCurrency] = useState<"usd" | "gbp">("usd");

  return (
    <section id="pricing" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        <div className="animate-drift absolute left-1/2 top-0 h-[480px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,rgba(56,189,248,0.16),transparent_65%)] blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Pricing"
          title={<>Straightforward rates. No retainers you can't leave.</>}
          subtitle="Start with a single task to see the quality, then move to a retainer only if it's genuinely saving you time."
        />

        <Reveal delay={120}>
          <div className="mx-auto mt-10 flex w-fit items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] p-1.5">
            {(["usd", "gbp"] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCurrency(c)}
                aria-pressed={currency === c}
                className={cn(
                  "rounded-full px-5 py-2 text-sm font-semibold transition-all duration-300",
                  currency === c
                    ? "bg-white text-ink-950 shadow-[0_8px_24px_-10px_rgba(255,255,255,0.6)]"
                    : "text-slate-300 hover:text-white",
                )}
              >
                {c === "usd" ? "🇺🇸 USD" : "🇬🇧 GBP"}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PLANS.map((p, i) => (
            <Reveal key={p.name} delay={i * 110}>
              <article
                className={cn(
                  "card-hover group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] border p-7",
                  p.popular
                    ? "border-brand-300/40 bg-gradient-to-b from-brand-400/[0.14] to-white/[0.02] shadow-[0_30px_80px_-40px_rgba(56,189,248,0.7)]"
                    : "border-white/10 bg-white/[0.035]",
                )}
              >
                {p.popular && (
                  <span className="absolute right-5 top-5 rounded-full bg-gradient-to-r from-brand-400 to-mint-400 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wider text-ink-950">
                    Most popular
                  </span>
                )}
                <h3 className="font-display text-lg font-bold text-white">{p.name}</h3>
                <p className="mt-2 min-h-[2.5rem] text-[13px] leading-snug text-slate-400">{p.best}</p>

                <p className="mt-6 flex items-end gap-1">
                  <span className="font-display text-4xl font-extrabold tracking-tight text-white">
                    {currency === "usd" ? `$${p.usd}` : `£${p.gbp}`}
                  </span>
                  <span className="pb-1.5 text-sm text-slate-400">{p.unit}</span>
                </p>

                <a
                  href="#contact"
                  className={cn(
                    "mt-6 inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-bold transition-all duration-300 hover:scale-[1.02]",
                    p.popular
                      ? "bg-gradient-to-r from-brand-400 to-mint-400 text-ink-950 shadow-[0_14px_36px_-14px_rgba(56,189,248,0.9)]"
                      : "border border-white/15 bg-white/[0.05] text-white hover:bg-white/10",
                  )}
                >
                  {p.cta}
                </a>

                <ul className="mt-7 space-y-3 border-t border-white/8 pt-6">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[13.5px] leading-snug text-slate-300">
                      <svg viewBox="0 0 20 20" className="mt-0.5 h-4 w-4 shrink-0 text-mint-400" fill="currentColor" aria-hidden="true">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.7-9.3a1 1 0 00-1.4-1.4L9 10.6 7.7 9.3a1 1 0 10-1.4 1.4l2 2a1 1 0 001.4 0l4-4z" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={150}>
          <div className="glass mx-auto mt-10 flex max-w-3xl flex-col items-center gap-3 rounded-3xl px-7 py-6 text-center sm:flex-row sm:text-left">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-mint-400/15 text-xl">
              🛡️
            </span>
            <p className="text-sm leading-relaxed text-slate-300">
              <span className="font-semibold text-white">Founding-client guarantee.</span> These are
              introductory rates for my first cohort of sellers and stay locked for six months. If the first
              task doesn't save you time, you don't pay for it. GBP shown as an equivalent — invoices can be
              issued in either currency.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
