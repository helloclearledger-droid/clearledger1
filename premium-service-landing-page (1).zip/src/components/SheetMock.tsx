import { CLEAN_ROWS, RAW_ROWS, TOTAL_REVENUE, type RawRow } from "@/data";
import { cn } from "@/utils/cn";

const isBad = (row: RawRow, key: NonNullable<RawRow["bad"]>[number]) => row.bad?.includes(key);

function StatusPill({ status }: { status: string }) {
  const tone =
    status === "Paid"
      ? "bg-mint-400/15 text-mint-300 ring-mint-400/30"
      : status === "Refunded"
        ? "bg-amber-400/15 text-amber-300 ring-amber-400/30"
        : "bg-sky-400/15 text-sky-300 ring-sky-400/30";
  return (
    <span className={cn("inline-flex rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1", tone)}>
      {status}
    </span>
  );
}

export function SheetMock({
  mode,
  compact = false,
  className,
}: {
  mode: "before" | "after";
  compact?: boolean;
  className?: string;
}) {
  const before = mode === "before";

  return (
    <div className={cn("overflow-hidden rounded-2xl border border-white/10 bg-ink-900/70", className)}>
      {/* window chrome */}
      <div className="flex items-center gap-2 border-b border-white/10 bg-white/[0.03] px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-rose-400/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-mint-400/70" />
        <p className="ml-2 truncate font-mono text-[11px] text-slate-400">
          {before ? "orders_export_raw.csv" : "orders_march_reconciled.xlsx"}
        </p>
        <span
          className={cn(
            "ml-auto inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider ring-1",
            before
              ? "bg-rose-500/10 text-rose-300 ring-rose-400/25"
              : "bg-mint-500/10 text-mint-300 ring-mint-400/25",
          )}
        >
          <span className={cn("h-1.5 w-1.5 rounded-full", before ? "bg-rose-400" : "bg-mint-400 animate-pulse-ring")} />
          {before ? "7 issues" : "Reconciled"}
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[520px] border-collapse text-left font-mono text-[11px] sm:text-xs">
          <thead>
            <tr className="bg-white/[0.04] text-[10px] uppercase tracking-wider text-slate-400">
              <th scope="col" className="px-3 py-2.5 font-semibold">Order</th>
              <th scope="col" className="px-3 py-2.5 font-semibold">Date</th>
              <th scope="col" className="px-3 py-2.5 font-semibold">Product</th>
              <th scope="col" className="px-3 py-2.5 text-right font-semibold">Qty</th>
              <th scope="col" className="px-3 py-2.5 text-right font-semibold">Price</th>
              {!before && <th scope="col" className="px-3 py-2.5 text-right font-semibold">Total</th>}
              <th scope="col" className="px-3 py-2.5 font-semibold">Status</th>
              {!compact && (
                <th scope="col" className="px-3 py-2.5 font-semibold">{before ? "Notes" : "Flag"}</th>
              )}
            </tr>
          </thead>
          <tbody className="text-slate-300">
            {before
              ? RAW_ROWS.map((r, i) => (
                  <tr key={i} className="border-t border-white/5 transition-colors hover:bg-white/[0.03]">
                    <td className={cn("px-3 py-2", isBad(r, "id") && "bg-rose-500/10 text-rose-300")}>{r.id}</td>
                    <td className={cn("px-3 py-2 whitespace-nowrap", isBad(r, "date") && "bg-rose-500/10 text-rose-300")}>{r.date}</td>
                    <td className={cn("px-3 py-2 whitespace-nowrap", isBad(r, "product") && "bg-rose-500/10 text-rose-300")}>{r.product}</td>
                    <td className="px-3 py-2 text-right">{r.qty}</td>
                    <td className={cn("px-3 py-2 text-right", isBad(r, "price") && "bg-rose-500/10 text-rose-300")}>{r.price}</td>
                    <td className={cn("px-3 py-2", isBad(r, "status") && "bg-rose-500/10 text-rose-300")}>{r.status}</td>
                    {!compact && (
                      <td className="px-3 py-2 text-[10px] text-rose-300/80">{r.note ?? ""}</td>
                    )}
                  </tr>
                ))
              : CLEAN_ROWS.map((r, i) => (
                  <tr key={i} className="border-t border-white/5 transition-colors hover:bg-mint-400/[0.06]">
                    <td className="px-3 py-2 text-white">{r.id}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.date}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.product}</td>
                    <td className="px-3 py-2 text-right">{r.qty}</td>
                    <td className="px-3 py-2 text-right">{r.price}</td>
                    <td className="px-3 py-2 text-right text-white">{r.total}</td>
                    <td className="px-3 py-2"><StatusPill status={r.status} /></td>
                    {!compact && (
                      <td className="px-3 py-2 text-[10px] text-mint-300/80">{r.flag ?? ""}</td>
                    )}
                  </tr>
                ))}
            {!before && (
              <tr className="border-t border-white/10 bg-mint-400/[0.07]">
                <td className="px-3 py-2.5 font-semibold text-white" colSpan={5}>
                  Total revenue
                </td>
                <td className="px-3 py-2.5 text-right font-semibold text-mint-300">{TOTAL_REVENUE}</td>
                <td className="px-3 py-2.5" colSpan={compact ? 1 : 2} />
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <p
        className={cn(
          "border-t border-white/10 px-4 py-3 text-[11px] leading-relaxed",
          before ? "text-rose-300/80" : "text-mint-300/85",
        )}
      >
        {before
          ? "Typical issues: inconsistent naming, missing IDs, mixed date formats, unlogged refunds, possible duplicates."
          : "Fixed: standardised dates, product names & prices, added missing order ID, logged refund, resolved duplicate flag."}
      </p>
    </div>
  );
}
