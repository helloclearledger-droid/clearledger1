import type { ReactNode } from "react";
import { Reveal } from "@/components/Reveal";
import { cn } from "@/utils/cn";

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}: {
  eyebrow: string;
  title: ReactNode;
  subtitle?: ReactNode;
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <div className={cn(align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl", className)}>
      <Reveal>
        <span className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-brand-300">
          <span className="h-1.5 w-1.5 rounded-full bg-mint-400" />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={80}>
        <h2 className="mt-5 font-display text-3xl font-extrabold leading-[1.12] tracking-tight text-white sm:text-[2.6rem]">
          {title}
        </h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={150}>
          <p className="mt-4 text-base leading-relaxed text-slate-400 sm:text-[17px]">{subtitle}</p>
        </Reveal>
      )}
    </div>
  );
}
