import { CountUp, Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";

const STEPS = [
  {
    n: "01",
    title: "Share your raw data",
    body: "Send an export, a spreadsheet link or read-only Drive access. CSV, XLSX, Google Sheets — whatever your platform spits out.",
    meta: "Takes you 5 minutes",
  },
  {
    n: "02",
    title: "I clean, organise & reconcile",
    body: "Every row is standardised, matched against payments and refunds, and anything that doesn't add up gets flagged with a reason.",
    meta: "Typically 24–48 hours",
  },
  {
    n: "03",
    title: "You get a ready-to-use sheet",
    body: "A tidy, formatted workbook plus a plain-English summary of exactly what was found and fixed. No jargon, no loose ends.",
    meta: "Plus a free follow-up call",
  },
];

const BENEFITS = [
  { t: "Hours back every week", d: "Stop losing evenings to reconciliation. Hand it over and get on with selling.", i: "⏱" },
  { t: "Margin you stop leaking", d: "Unlogged refunds, wrong prices and unmatched payouts caught before the month closes.", i: "📈" },
  { t: "Decisions with confidence", d: "Restock, reprice and forecast from numbers that actually tie out across channels.", i: "🎯" },
  { t: "Accountant-ready books", d: "Clean, consistent records your bookkeeper or accountant can work from immediately.", i: "🧾" },
  { t: "No new software", d: "Everything lands in the Excel or Google Sheets file you already use. Zero learning curve.", i: "🗂" },
  { t: "UK & US friendly hours", d: "Overlapping coverage for both timezones, with clear turnaround commitments in writing.", i: "🌍" },
];

export function Process() {
  return (
    <section id="process" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="How it works"
          title={<>Three steps from messy export to reliable sheet.</>}
          subtitle="Low friction on your side by design. You send data once, then you get your time back."
        />

        <div className="relative mt-16">
          <div
            aria-hidden="true"
            className="absolute left-6 top-0 hidden h-full w-px bg-gradient-to-b from-brand-400/60 via-mint-400/40 to-transparent lg:left-0 lg:top-12 lg:h-px lg:w-full lg:bg-gradient-to-r"
          />
          <ol className="grid gap-8 lg:grid-cols-3 lg:gap-8">
            {STEPS.map((s, i) => (
              <Reveal as="li" key={s.n} delay={i * 150} className="relative">
                <div className="group card-hover relative h-full rounded-[1.75rem] border border-white/10 bg-white/[0.035] p-7 pt-9">
                  <span className="absolute -top-6 left-7 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-400 to-mint-400 font-display text-sm font-extrabold text-ink-950 shadow-[0_12px_30px_-12px_rgba(56,189,248,0.9)] transition-transform duration-500 group-hover:scale-110">
                    {s.n}
                  </span>
                  <h3 className="mt-3 font-display text-xl font-bold text-white">{s.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-400">{s.body}</p>
                  <p className="mt-5 inline-flex rounded-full bg-white/5 px-3 py-1.5 text-[12px] font-medium text-brand-300">
                    {s.meta}
                  </p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>

        {/* Benefits */}
        <div className="mt-28">
          <SectionHeading
            eyebrow="Why it matters"
            title={<>What clean data actually buys you.</>}
            subtitle="Tidy spreadsheets are the mechanism. The outcome is time, margin and a business you can steer."
          />

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {BENEFITS.map((b, i) => (
              <Reveal key={b.t} delay={i * 90}>
                <div className="card-hover group relative h-full overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent p-6">
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-300/50 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                  />
                  <span className="text-2xl">{b.i}</span>
                  <h3 className="mt-4 font-display text-base font-bold text-white">{b.t}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-400">{b.d}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={120}>
            <dl className="mt-14 grid gap-4 rounded-[1.75rem] border border-white/10 bg-white/[0.03] p-8 sm:grid-cols-3">
              {[
                { v: <CountUp to={12} suffix="+ hrs" />, l: "Admin time saved per month, typical retainer client" },
                { v: <CountUp to={98} suffix="%" />, l: "Of flagged mismatches resolved on first pass" },
                { v: <CountUp to={48} suffix="h" />, l: "Standard turnaround on one-off cleanup tasks" },
              ].map((s, i) => (
                <div key={i} className="text-center">
                  <dt className="font-display text-3xl font-extrabold text-gradient sm:text-4xl">{s.v}</dt>
                  <dd className="mx-auto mt-2 max-w-[16rem] text-[13px] leading-snug text-slate-400">{s.l}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
