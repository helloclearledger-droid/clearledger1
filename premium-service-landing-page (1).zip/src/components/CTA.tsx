import { useState, type FormEvent } from "react";
import { Reveal } from "@/components/Reveal";
import { AUDIT_MAILTO, EMAIL } from "@/site";

const PERKS = ["Free 30-min data audit", "No obligation, no lock-in", "Reply within 1 business day"];

export function CTA() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
    if (!valid) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setSent(true);
    window.location.href = AUDIT_MAILTO(email.trim());
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.25rem] border border-white/12 bg-gradient-to-b from-white/[0.08] to-white/[0.02] px-6 py-16 text-center sm:px-14 sm:py-20">
            <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
              <div className="absolute inset-0 grid-lines opacity-40 [mask-image:radial-gradient(ellipse_60%_60%_at_50%_40%,#000,transparent)]" />
              <div className="animate-drift absolute left-1/2 top-[-20%] h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,rgba(56,189,248,0.3),transparent_65%)] blur-3xl" />
              <div className="animate-drift absolute bottom-[-30%] right-[10%] h-[320px] w-[420px] rounded-full bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.25),transparent_65%)] blur-3xl [animation-delay:-9s]" />
            </div>

            <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-mint-300">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint-400" />
              Taking 3 new clients this month
            </span>

            <h2 className="mx-auto mt-7 max-w-3xl font-display text-3xl font-extrabold leading-[1.1] tracking-tight text-white sm:text-5xl">
              Send me your messiest export.
              <br />
              <span className="text-gradient animate-shimmer">I'll show you what's hiding in it.</span>
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-slate-300">
              Free 30-minute audit: I'll review a sample of your data, tell you exactly what's broken and what
              it's likely costing you — whether or not you hire me.
            </p>

            {sent ? (
              <div className="glass mx-auto mt-10 max-w-md rounded-2xl px-6 py-7">
                <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-mint-400/15 text-xl text-mint-300 animate-pulse-ring">
                  ✓
                </span>
                <p className="mt-4 font-display text-lg font-bold text-white">Your email client is opening</p>
                <p className="mt-2 text-sm text-slate-400">
                  If nothing happened, email{" "}
                  <a
                    href={`mailto:${EMAIL}`}
                    className="font-medium text-brand-300 underline-offset-4 transition-colors hover:text-white hover:underline"
                  >
                    {EMAIL}
                  </a>{" "}
                  and I'll reply within one business day.
                </p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="mx-auto mt-10 max-w-lg" noValidate>
                <div className="glass flex flex-col gap-2 rounded-2xl p-2 sm:flex-row sm:rounded-full">
                  <label htmlFor="cta-email" className="sr-only">
                    Your work email
                  </label>
                  <input
                    id="cta-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@yourstore.com"
                    aria-invalid={Boolean(error)}
                    aria-describedby={error ? "cta-error" : undefined}
                    className="w-full flex-1 rounded-xl bg-transparent px-5 py-3.5 text-[15px] text-white placeholder:text-slate-500 focus:outline-none sm:rounded-full"
                  />
                  <button
                    type="submit"
                    className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-brand-400 to-mint-400 px-6 py-3.5 text-[15px] font-bold text-ink-950 transition-transform duration-300 hover:scale-[1.02] sm:rounded-full"
                  >
                    <span className="relative z-10">Book my free audit</span>
                    <span className="absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.7),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
                  </button>
                </div>
                {error && (
                  <p id="cta-error" role="alert" className="mt-3 text-sm text-rose-300">
                    {error}
                  </p>
                )}
              </form>
            )}

            <ul className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[13px] text-slate-400">
              {PERKS.map((p) => (
                <li key={p} className="inline-flex items-center gap-2">
                  <span className="text-mint-400">✓</span>
                  {p}
                </li>
              ))}
            </ul>

            <p className="mt-6 text-[13px] text-slate-500">
              Prefer to email directly?{" "}
              <a
                href={`mailto:${EMAIL}`}
                className="font-medium text-brand-300 underline-offset-4 transition-colors hover:text-white hover:underline"
              >
                {EMAIL}
              </a>
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
