export function Logo({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <span
      className={`relative inline-flex items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-brand-400 via-brand-500 to-mint-500 shadow-[0_8px_24px_-8px_rgba(56,189,248,0.8)] transition-transform duration-500 group-hover:rotate-6 ${className}`}
      aria-hidden="true"
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5 text-ink-950" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="4" />
        <path d="M3 9h18M9 9v12" />
        <path d="M13 15.2l2 2 4-4.6" />
      </svg>
      <span className="pointer-events-none absolute inset-0 bg-[linear-gradient(110deg,transparent_30%,rgba(255,255,255,0.65)_50%,transparent_70%)] animate-shimmer" />
    </span>
  );
}
