import { Logo } from "@/components/Logo";
import { EMAIL } from "@/site";

const COLUMNS = [
  {
    title: "Services",
    links: [
      { l: "Data cleanup", h: "#services" },
      { l: "Reconciliation", h: "#services" },
      { l: "Monthly retainers", h: "#pricing" },
      { l: "Sample work", h: "#proof" },
    ],
  },
  {
    title: "Company",
    links: [
      { l: "How it works", h: "#process" },
      { l: "Pricing", h: "#pricing" },
      { l: "FAQ", h: "#faq" },
      { l: "Book an audit", h: "#contact" },
    ],
  },
];

const DETAILS = [
  { label: "Email", value: EMAIL, href: `mailto:${EMAIL}` },
  { label: "Coverage", value: "UK & US sellers" },
  { label: "Hours", value: "Mon–Fri · UK + US overlap" },
  { label: "Response", value: "Within 1 business day" },
];

export function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-ink-900/60 pt-16">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 pb-14 lg:grid-cols-[1.5fr_1fr_1fr_1.3fr]">
          <div>
            <a href="#top" className="group inline-flex items-center gap-2.5" aria-label="ClearLedger home">
              <Logo className="h-9 w-9" />
              <span className="font-display text-[17px] font-bold tracking-tight text-white">
                Clear<span className="text-brand-300">Ledger</span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-400">
              Freelance e-commerce operations support. Clean data, reconciled books and fewer silent losses
              for small Amazon, Shopify and Etsy sellers across the UK and US.
            </p>
            <a
              href={`mailto:${EMAIL}`}
              className="glass group mt-6 inline-flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium text-slate-200 transition-all duration-300 hover:-translate-y-0.5 hover:text-white"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-400/15 text-brand-300">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
                  <path d="M3 5h18a1 1 0 011 1v12a1 1 0 01-1 1H3a1 1 0 01-1-1V6a1 1 0 011-1zm1.6 2L12 12.3 19.4 7z" />
                </svg>
              </span>
              {EMAIL}
            </a>
          </div>

          {COLUMNS.map((c) => (
            <div key={c.title}>
              <h2 className="font-display text-sm font-bold uppercase tracking-wider text-white">{c.title}</h2>
              <ul className="mt-5 space-y-3">
                {c.links.map((l) => (
                  <li key={l.l}>
                    <a
                      href={l.h}
                      className="group inline-flex items-center gap-1.5 text-sm text-slate-400 transition-colors hover:text-white"
                    >
                      <span className="h-px w-0 bg-brand-300 transition-all duration-300 group-hover:w-3" />
                      {l.l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h2 className="font-display text-sm font-bold uppercase tracking-wider text-white">Details</h2>
            <dl className="mt-5 space-y-3.5">
              {DETAILS.map((d) => (
                <div key={d.label}>
                  <dt className="text-[11px] uppercase tracking-wider text-slate-600">{d.label}</dt>
                  <dd className="text-sm text-slate-400">
                    {d.href ? (
                      <a
                        href={d.href}
                        className="break-all transition-colors hover:text-white"
                      >
                        {d.value}
                      </a>
                    ) : (
                      d.value
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 py-7 text-[13px] text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} ClearLedger Seller Support Services. All rights reserved.</p>
          <p className="inline-flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-mint-400 animate-pulse" />
            Accepting new clients
          </p>
        </div>
      </div>
    </footer>
  );
}
