import { useState } from "react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";
import { QUESTION_MAILTO } from "@/site";
import { cn } from "@/utils/cn";

const FAQS = [
  {
    q: "What exactly do you need from me to start?",
    a: "A raw export is enough — CSV, XLSX or a Google Sheets link works. Orders, inventory or expense data, exactly as your platform produces it. No pre-tidying required; messy is the whole point.",
  },
  {
    q: "Is my sales and customer data safe?",
    a: "Yes. Data is handled under a signed NDA on request, stored only for the duration of the job in an access-controlled drive, and deleted on completion unless you're on a retainer. I never need payment credentials or store logins — read-only exports are enough.",
  },
  {
    q: "Which platforms do you work with?",
    a: "Amazon Seller Central, Shopify, Etsy and eBay exports, plus payment data from Stripe, PayPal and Wise. Output lands in Excel or Google Sheets, formatted so your bookkeeper, Xero or QuickBooks can take it straight in.",
  },
  {
    q: "How fast is turnaround?",
    a: "One-off cleanup and reconciliation tasks are typically delivered in 24–48 hours. Retainer clients get priority scheduling, and Growth clients get same-business-day acknowledgement on every request.",
  },
  {
    q: "I'm in the US — do timezones matter?",
    a: "No. I work overlapping UK and US hours, respond within one business day, and every job has a written turnaround commitment up front so you're never waiting on an unclear timeline.",
  },
  {
    q: "What if the sheet comes back and it's not right?",
    a: "Revisions are included until it matches what you expected. If the first task genuinely doesn't save you time, you don't pay for it — that's the founding-client guarantee.",
  },
  {
    q: "Do you handle VAT or sales tax?",
    a: "I prepare VAT- and sales-tax-ready records: categorised, reconciled and formatted for your accountant. I don't file returns or give tax advice — that stays with your qualified accountant.",
  },
  {
    q: "Can I try before committing to a retainer?",
    a: "That's the recommended path. Start with a one-time cleanup or a single reconciliation task. Most clients move to a retainer after seeing the first deliverable, but there's never any obligation.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
          <div>
            <SectionHeading
              align="left"
              eyebrow="FAQ"
              title={<>Questions sellers ask before sending their first file.</>}
              subtitle="Still unsure about something? Ask directly — plain answers, no sales pressure."
            />
            <Reveal delay={200}>
              <a
                href={QUESTION_MAILTO}
                className="glass group mt-8 inline-flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold text-white transition-all duration-300 hover:bg-white/10"
              >
                Email me your question
                <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
              </a>
            </Reveal>
          </div>

          <div className="space-y-3">
            {FAQS.map((f, i) => {
              const isOpen = open === i;
              return (
                <Reveal key={f.q} delay={i * 60}>
                  <div
                    className={cn(
                      "overflow-hidden rounded-2xl border transition-all duration-400",
                      isOpen
                        ? "border-brand-300/35 bg-white/[0.06]"
                        : "border-white/10 bg-white/[0.025] hover:border-white/20",
                    )}
                  >
                    <h3>
                      <button
                        type="button"
                        onClick={() => setOpen(isOpen ? null : i)}
                        aria-expanded={isOpen}
                        aria-controls={`faq-panel-${i}`}
                        className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
                      >
                        <span className="text-[15px] font-semibold text-white sm:text-base">{f.q}</span>
                        <span
                          className={cn(
                            "relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/15 transition-all duration-400",
                            isOpen && "rotate-180 border-brand-300/50 bg-brand-400/15",
                          )}
                          aria-hidden="true"
                        >
                          <svg viewBox="0 0 20 20" className="h-3.5 w-3.5 text-brand-300" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
                            <path d="M5 8l5 5 5-5" />
                          </svg>
                        </span>
                      </button>
                    </h3>
                    <div
                      id={`faq-panel-${i}`}
                      className={cn(
                        "grid transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
                        isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                      )}
                    >
                      <div className="overflow-hidden">
                        <p className="px-5 pb-5 text-[14.5px] leading-relaxed text-slate-400 sm:px-6">{f.a}</p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
