import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";

const SERVICES = [
  {
    tag: "Core",
    title: "Data cleanup",
    body: "Turn messy raw exports — orders, inventory, expenses — into clean, consistent, filterable sheets you can hand to anyone.",
    points: ["Standardised dates, SKUs & product names", "De-duplication and missing ID recovery", "Formatted totals, filters and summaries"],
    accent: "from-brand-400/25 to-brand-500/5",
    icon: (
      <path d="M4 7h16M4 12h10M4 17h7M17 15l2 2 3-3.5" />
    ),
  },
  {
    tag: "Core",
    title: "Reconciliation",
    body: "Match orders against payments and refunds, line by line, and flag every mismatch before it becomes a loss.",
    points: ["Orders vs payouts vs refunds matching", "Flagged variance report with root cause", "Fee, chargeback and VAT/sales-tax checks"],
    accent: "from-mint-400/25 to-mint-500/5",
    icon: <path d="M7 8h10M7 8l-3 3 3 3M17 16H7m10 0l3-3-3-3" />,
  },
  {
    tag: "Ongoing",
    title: "Monthly support",
    body: "A dependable pair of hands each month for the recurring data jobs: stock errors, pricing mismatches, reporting.",
    points: ["Rolling monthly cleanup & reconciliation", "Stock and pricing error monitoring", "Simple owner-friendly reporting pack"],
    accent: "from-indigo-400/25 to-indigo-500/5",
    icon: <path d="M12 3v3m0 12v3M3 12h3m12 0h3M5.6 5.6l2.1 2.1m8.6 8.6l2.1 2.1m0-12.8l-2.1 2.1M7.7 16.3l-2.1 2.1" />,
  },
];

const EXTRAS = [
  "Inventory audits",
  "Refund tracking",
  "Payout matching",
  "Expense categorisation",
  "Multi-channel merges",
  "Custom dashboards",
  "VAT-ready exports",
  "Google Sheets automation",
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="What I do"
          title={<>Three services. One outcome: numbers you can trust.</>}
          subtitle="Everything is done by hand-checked process — not a black-box tool that silently guesses. You always get a short summary of what was found and fixed."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <Reveal key={s.title} delay={i * 130}>
              <article className="card-hover group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/[0.035] p-7">
                <div
                  aria-hidden="true"
                  className={`pointer-events-none absolute inset-x-0 -top-24 h-48 bg-gradient-to-b ${s.accent} opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100`}
                />
                <div className="flex items-center justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-white/15 to-white/5 ring-1 ring-white/10">
                    <svg viewBox="0 0 24 24" className="h-6 w-6 text-brand-300" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">
                      {s.icon}
                    </svg>
                  </span>
                  <span className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    {s.tag}
                  </span>
                </div>

                <h3 className="mt-6 font-display text-xl font-bold text-white">{s.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">{s.body}</p>

                <ul className="mt-6 space-y-3 border-t border-white/8 pt-6">
                  {s.points.map((p) => (
                    <li key={p} className="flex items-start gap-2.5 text-sm text-slate-300">
                      <svg viewBox="0 0 20 20" className="mt-0.5 h-4 w-4 shrink-0 text-mint-400" fill="currentColor" aria-hidden="true">
                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.7-9.3a1 1 0 00-1.4-1.4L9 10.6 7.7 9.3a1 1 0 10-1.4 1.4l2 2a1 1 0 001.4 0l4-4z" />
                      </svg>
                      {p}
                    </li>
                  ))}
                </ul>

              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={150}>
          <div className="mt-10 flex flex-wrap justify-center gap-2.5">
            {EXTRAS.map((e) => (
              <span
                key={e}
                className="glass rounded-full px-4 py-2 text-[13px] text-slate-300 transition-all duration-300 hover:-translate-y-0.5 hover:text-white"
              >
                {e}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
