import { useState } from "react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";
import { SheetMock } from "@/components/SheetMock";
import { cn } from "@/utils/cn";

const TABS = [
  { id: "before", label: "Raw export", hint: "As received from the client" },
  { id: "after", label: "Cleaned & reconciled", hint: "Delivered back within 48h" },
] as const;

const FIXES = [
  { k: "Dates", v: "3 formats → one ISO standard" },
  { k: "Products", v: "4 naming variants merged" },
  { k: "Pricing", v: "1 mismatch corrected (13.99 → 12.99)" },
  { k: "Refunds", v: "1 unlogged refund recovered" },
  { k: "Duplicates", v: "1 suspected dup verified as real" },
  { k: "IDs", v: "1 missing order ID assigned" },
];

export function Showcase() {
  const [tab, setTab] = useState<"before" | "after">("after");

  return (
    <section id="proof" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        <div className="animate-drift absolute left-1/2 top-1/3 h-[520px] w-[720px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.16),transparent_65%)] blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Real sample work"
          title={<>Watch a real export go from chaos to clean.</>}
          subtitle="This is an anonymised slice of an actual client job — seven rows, seven problems, one tidy deliverable with a revenue total you can rely on."
        />

        <Reveal delay={120} className="mt-12">
          <div className="mx-auto flex max-w-md items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] p-1.5" role="tablist" aria-label="Sample work view">
            {TABS.map((t) => (
              <button
                key={t.id}
                role="tab"
                type="button"
                aria-selected={tab === t.id}
                aria-controls={`panel-${t.id}`}
                id={`tab-${t.id}`}
                onClick={() => setTab(t.id)}
                className={cn(
                  "relative flex-1 rounded-xl px-4 py-3 text-sm font-semibold transition-all duration-300",
                  tab === t.id
                    ? "bg-gradient-to-r from-brand-400 to-mint-400 text-ink-950 shadow-[0_10px_30px_-12px_rgba(56,189,248,0.9)]"
                    : "text-slate-300 hover:bg-white/5 hover:text-white",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        </Reveal>

        <Reveal delay={180} className="mt-8">
          <div className="relative mx-auto max-w-5xl">
            <div
              aria-hidden="true"
              className="absolute -inset-4 -z-10 rounded-[2.5rem] bg-[conic-gradient(from_140deg_at_50%_50%,rgba(56,189,248,0.22),rgba(52,211,153,0.18),rgba(99,102,241,0.2),rgba(56,189,248,0.22))] blur-2xl"
            />
            <div className="glass rounded-[1.9rem] p-3 sm:p-4">
              {TABS.map((t) => (
                <div
                  key={t.id}
                  role="tabpanel"
                  id={`panel-${t.id}`}
                  aria-labelledby={`tab-${t.id}`}
                  hidden={tab !== t.id}
                >
                  <div className="mb-3 flex items-center justify-between px-1">
                    <p className="text-xs font-medium text-slate-400">{t.hint}</p>
                    <p className="hidden text-xs text-slate-500 sm:block">Scroll table horizontally →</p>
                  </div>
                  <SheetMock mode={t.id} />
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-5xl gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FIXES.map((f, i) => (
            <Reveal key={f.k} delay={i * 80}>
              <div className="card-hover flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-mint-400/15 text-xs font-bold text-mint-300">
                  ✓
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">{f.k}</p>
                  <p className="text-[13px] text-slate-400">{f.v}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
