import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";

const QUOTES = [
  {
    quote:
      "I sent over eight months of Shopify and Stripe exports that I'd been avoiding. Came back organised, reconciled, and with three refunds I'd never logged. It paid for itself instantly.",
    name: "Hannah M.",
    role: "Shopify seller · Manchester, UK",
    initials: "HM",
    stat: "£412 recovered",
  },
  {
    quote:
      "The flagged mismatch report is the bit I didn't know I needed. It told me exactly which orders didn't tie out and why, in plain English. My accountant was thrilled.",
    name: "Dan R.",
    role: "Amazon FBA · Austin, TX",
    initials: "DR",
    stat: "6 hrs/week saved",
  },
  {
    quote:
      "I run my Etsy shop solo. Handing the monthly spreadsheet over was the first time in two years I've finished a month without dreading the numbers.",
    name: "Priya S.",
    role: "Etsy seller · Leeds, UK",
    initials: "PS",
    stat: "Monthly retainer",
  },
  {
    quote:
      "Fast, precise, and asks the right questions instead of guessing. The turnaround was under 48 hours and the sheet was genuinely ready to use.",
    name: "Marcus T.",
    role: "Multi-channel seller · Brooklyn, NY",
    initials: "MT",
    stat: "1,400 rows cleaned",
  },
];

function Stars() {
  return (
    <div className="flex gap-0.5" aria-label="5 out of 5 stars">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 20 20" className="h-4 w-4 text-amber-300" fill="currentColor" aria-hidden="true">
          <path d="M10 1.8l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L2.2 7.5l5.4-.8L10 1.8z" />
        </svg>
      ))}
    </div>
  );
}

export function Testimonials() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Client feedback"
          title={<>Sellers who stopped fighting their spreadsheets.</>}
          subtitle="Early clients across the UK and US — small teams and solo operators who just needed the numbers to make sense again."
        />

        <div className="mt-14 grid gap-5 lg:grid-cols-2">
          {QUOTES.map((q, i) => (
            <Reveal key={q.name} delay={i * 110}>
              <figure className="card-hover group relative flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/[0.035] p-7">
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute -right-8 -top-10 font-display text-[9rem] leading-none text-white/[0.04] transition-transform duration-700 group-hover:scale-110"
                >
                  ”
                </span>
                <div className="flex items-center justify-between gap-4">
                  <Stars />
                  <span className="rounded-full bg-mint-400/12 px-3 py-1 text-[11px] font-semibold text-mint-300 ring-1 ring-mint-400/25">
                    {q.stat}
                  </span>
                </div>
                <blockquote className="mt-5 text-[15px] leading-relaxed text-slate-200 sm:text-base">
                  {q.quote}
                </blockquote>
                <figcaption className="mt-7 flex items-center gap-3 border-t border-white/8 pt-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-brand-400/80 to-mint-400/80 font-display text-sm font-bold text-ink-950">
                    {q.initials}
                  </span>
                  <span>
                    <span className="block text-sm font-semibold text-white">{q.name}</span>
                    <span className="block text-[13px] text-slate-400">{q.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
