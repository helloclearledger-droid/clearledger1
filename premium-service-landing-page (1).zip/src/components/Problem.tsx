import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "@/components/SectionHeading";

const PAINS = [
  {
    icon: "🧩",
    title: "Data scattered everywhere",
    body: "Orders in Shopify, payouts in Stripe, fees in Amazon, stock in a spreadsheet someone edited last April. Nothing agrees.",
  },
  {
    icon: "⏳",
    title: "No time, no team",
    body: "You're packing orders and answering customers. Reconciling three exports at 11pm is the job that never gets done.",
  },
  {
    icon: "💸",
    title: "Silent money leaks",
    body: "Missed refunds, unmatched payouts and pricing slips rarely look dramatic — they just shave margin every single month.",
  },
  {
    icon: "🌫️",
    title: "Numbers you don't trust",
    body: "When the sheet is messy, every decision becomes a guess: what to restock, what to price, what's actually profitable.",
  },
];

export function Problem() {
  return (
    <section className="relative py-24 sm:py-32">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent"
      />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="The problem"
          title={<>If your spreadsheet is the scariest part of your business, you're not alone.</>}
          subtitle="Most small sellers don't have a data problem because they're careless. They have one because the platforms never agree with each other — and nobody has the hours to make them."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PAINS.map((p, i) => (
            <Reveal key={p.title} delay={i * 110}>
              <article className="card-hover group relative h-full overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-6">
                <span
                  aria-hidden="true"
                  className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-rose-500/10 blur-2xl transition-opacity duration-500 group-hover:opacity-80"
                />
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/[0.06] text-xl ring-1 ring-white/10 transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110">
                  {p.icon}
                </span>
                <h3 className="mt-5 font-display text-lg font-bold text-white">{p.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-slate-400">{p.body}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mx-auto mt-12 max-w-2xl text-center text-base text-slate-300">
            <span className="font-semibold text-white">The fix isn't more software.</span> It's one person who
            takes the raw exports off your hands and hands back a sheet you can actually act on.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
