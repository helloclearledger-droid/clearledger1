export const EMAIL = "hello.clearledger@gmail.com";

export const AUDIT_MAILTO = (from?: string) =>
  `mailto:${EMAIL}?subject=${encodeURIComponent("Free data audit request")}&body=${encodeURIComponent(
    `Hi,\n\nI'd like a free data audit.\n\n${from ? `My email: ${from}\n` : ""}Platform (Amazon / Shopify / Etsy / other):\nRough monthly order volume:\nBiggest data headache right now:\n\nThanks!`,
  )}`;

export const QUESTION_MAILTO = `mailto:${EMAIL}?subject=${encodeURIComponent(
  "Question about your seller support services",
)}&body=${encodeURIComponent("Hi,\n\nI have a question before getting started:\n\n")}`;
